import React from "react";
import {View, Text, StyleSheet, TextInput, TouchableOpacity} from "react-native";


export default class App extends React.Component{
  state={
    num1:0,
    num2:0,
    resultado:0,
  };

  somar = this.somar.bind(this);
  subtrair = this.subtrair.bind(this);
  multiplicar = this.multiplicar.bind(this);
  dividir = this.dividir.bind(this);

  somar(){
    this.state.resultado = Number(this.state.num1) + Number(this.state.num2);
    this.setState(this.state);
  }

   subtrair(){
    this.state.resultado = Number(this.state.num1) - Number(this.state.num2);
    this.setState(this.state);
  }

   multiplicar(){
    this.state.resultado = Number(this.state.num1) * Number(this.state.num2);
    this.setState(this.state);
  }

   dividir(){
    this.state.resultado = Number(this.state.num1) / Number(this.state.num2);
    this.setState(this.state);
  }

  render(){
    return(
      <View style={styles.container}>
        <Text>Minha calculadora!</Text>

        {/*View de Input */}
        <View>
          <TextInput style={styles.input} placeholder="Número 01" onChangeText={(num1)=>this.setState({num1})}/>
          <TextInput style={styles.input} placeholder="Número 02"onChangeText={(num2)=> this.setState({num2})}/>
        </View>

        {/*View de Botões*/}
        <View style={styles.containerBotoes}>
          <TouchableOpacity style={styles.botao} onPress={this.somar}>
            <Text style={styles.textoBotao}>+</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.botao} onPress={this.subtrair}>
            <Text style={styles.textoBotao}>-</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.botao} onPress={this.multiplicar}>
            <Text style={styles.textoBotao}>*</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.botao} onPress={this.dividir}>
            <Text style={styles.textoBotao}>/</Text>
          </TouchableOpacity>
        </View>

        <View>
          <Text style={styles.resultado}>{this.state.resultado}</Text>
        </View>


      </View>
    );
  }
}


const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "white",
    alignItems: "center",
    justifyContent: "center",
  },
  input: {
    width: 250,
    borderWidth: 2,
    borderColor: "blue",
    textAlign: "center",
    fontSize:25,
    marginBottom: 5,
  }, 
    botao:{
    backgroundColor:"red",
    width: 50,
    height: 50,
    borderRadius: 10,
    margin: "auto",
    paddingVertical: 12,
    paddingHorizontal: 12,
  },
  containerBotoes:{
    width: 250,
    flexDirection: "row",
    borderWidth: 2,
    borderColor: "blue",
    marginBottom:5,
    padding: 2,
  },
  textoBotao:{
    textAlign: "center",
    fontWeight: "hold",
    lineHeight: 30,
    color: "white",
  },
  resultado:{
    width: 250,
    borderWidth: 2,
    borderColor: 'blue',
    textAlign: "center",
    fontSize: 30,
  }
});