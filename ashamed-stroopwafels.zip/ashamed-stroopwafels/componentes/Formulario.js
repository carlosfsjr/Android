import React, {useState, useContext} from 'react';
import { StyleSheet, TextInput, Text, View, TouchableOpacity} from 'react-native';

import {useNavigation} from '@react-navigation/native';
import { ListaProdutos } from './Lista';

export default function Formulario(){
    const navigation = useNavigation();
    const [inputCod, setInputCod] = useState('');
    const [inputDesc, setInputDesc] = useState('');
    const [inputPreco, setInputPreco] = useState('');
    const [inputQtd, setInputQtd] = useState('');

    const {produtos} = useContext(ListaProdutos);
    const {addProdutos} = useContext(ListaProdutos);

    function novoProduto(){
        if(inputCod == '' || inputDesc == '' || inputPreco == '' || inputQtd == ''){
            alert('Os campos devem estar preenchidos');
            return;
        }
         
        addProdutos(produtos, inputCod, inputDesc, inputPreco, inputQtd);

        navigation.navigate('Home');
    }

    return(
        <View style= {styles.container}>
            <View>
                <TextInput
                    style={styles.entrada}
                    placeholder='Código'
                    placeholderTextColor={'red'}
                    value={inputCod}
                    onChangeText={(text) => setInputCod(text)}/>           

                <TextInput
                    style={styles.entrada}
                    placeholder='Descrição'
                    placeholderTextColor={'red'}
                    value={inputDesc}
                    onChangeText={(text) => setInputDesc(text)}/>

                <TextInput
                    style={styles.entrada}
                    placeholder='Preço'
                    placeholderTextColor={'red'}
                    value={inputPreco}
                    onChangeText={(text) => setInputPreco(text)}/>

                <TextInput
                    style={styles.entrada}
                    placeholder='Quantidade'
                    placeholderTextColor={'red'}
                    value={inputQtd}
                    onChangeText={(text) => setInputQtd(text)}/>

           </View>
           <View style={styles.containerBotao}>

                <TouchableOpacity
                    style={styles.botao}
                    onPress={novoProduto}>
                        <Text style={styles.textoBotao}>Adicionar</Text>
                </TouchableOpacity>
            </View>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
    flex: 1,
    backgroundColor: "white",
    alignItems: "center",
    justifyContent: "center",
  },
  entrada: {  
    justifyContent:"center",
    width: 320,
    borderWidth: 2,
    borderColor: "black",
    textAlign: "center",
    fontSize:20,
    marginBottom: 5,
  },
  botao: {
    backgroundColor:"black",
    width: 320,
    height: 40,
    borderRadius: 10,
    margin: 1,
    paddingVertical: 12,
    paddingHorizontal: 12,
    cursor: 'pointer',
  },
  textoBotao: {
    color: "white",
    fontWeight: "bold",
    textAlign: "center",
  },
  containerBotao: {
    width: 320,
    flexDirection: "row",
    marginBottom:5,
    padding: 2,
    justifyContent: "center",
  }
});