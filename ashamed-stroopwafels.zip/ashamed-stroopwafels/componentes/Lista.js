import React, {createContext} from 'react';

export const ListaProdutos = createContext({});


function addProdutos(produtos, inputCod, inputDesc, inputPreco, inputQtd){
    produtos.push({cod: inputCod, descricao: inputDesc, preco: inputPreco, quantidade: inputQtd});
}

function Lista({children}){
    return(
        <ListaProdutos.Provider value = {
                                {produtos: [{cod: '', descricao: '', preco: '',                                             quantidade:''}], addProdutos}
                            }>
            {children}
        </ListaProdutos.Provider>
    );
}

export default Lista;