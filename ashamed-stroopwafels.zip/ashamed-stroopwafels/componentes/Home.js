import React, {useContext} from 'react';
import { StyleSheet,  Text, View, TouchableOpacity, FlatList, Alert} from 'react-native';

import {useNavigation} from '@react-navigation/native';
import { ListaProdutos } from './Lista';

function Alerta(){
   alert('Produtos\n'+  'Código: '+ ListaProdutos.cod +'\nDescrição: ' + this.descricao + '\nPreço: ' + this.preco + '\nQuatidade: ' + this.qtd)
            return;
}

export default function Home(){
    const {produtos} = useContext(ListaProdutos);
    const navigation = useNavigation();

    return(
        
        <View style={styles.container}>
          <TouchableOpacity style={styles.containerItem} onPress={Alerta}> 
            <FlatList
                style={styles.lista}
                data={produtos}
                renderItem={({ item }) => (
                    <Text style={styles.item}>{
                        (item.cod != '' && item.descricao != '')?'[' + item.cod + '] - ' + item.descricao:''
                        }</Text>
                )}
            />
            </TouchableOpacity>

            <TouchableOpacity 
            style= {styles.floatButton}
            onPress={() => navigation.navigate('Formulario')}>
                <Text style={styles.textoBotao}>+</Text>
            </TouchableOpacity>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: 'white',
        alignItems: 'center',
    },
    floatButton: {
        borderWidth: 1,
        alignItems: 'center',
        justifyContent: 'center',
        width: 70,
        height: 70,
        position: 'absolute',
        bottom: 10,
        right: 10,
        backgroundColor: 'green',
        borderRadius: 100,
    },
    textoBotao: {
        fontSize: 30,
        color: 'white',
    },
    lista:{
        marginTop: 35,
    },
    item: {
        marginBottom: 10,
        borderBottomColor:"black",
        borderBottomWidth: 2,
    },
    containerItem:{
      width:320,
  },
});